package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Component
@Scope(value="prototype")
public class Student {

//	@GetMapping(value = "/")
//	public String hello() {
//		return "hello, Skill-Lync";
//	}
//
//	@GetMapping(value = "/json")
//	public Map<String, Object> get() {
//		Map<String, Object> map = new HashMap<>();
//		map.put("name", "skill lync");
//		map.put("location", "Chennai");
//		return map;
//	}

	public Student() {
		super();
		System.out.println(" Object created");
	}

	private int aid;
	private String Name;
	private String tech;
	
	@Autowired
//	@Qualifier("lap1")
	private Laptop laptop;

	public Laptop getLaptop() {
		return laptop;
	}

	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public void show() {
		System.out.println("in show");
		laptop.compile();
	}

}
