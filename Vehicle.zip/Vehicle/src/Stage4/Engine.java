package Stage4;

public interface Engine {
	
	String getEngineType(); 

}
