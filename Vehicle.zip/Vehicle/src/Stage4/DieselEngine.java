package Stage4;

public class DieselEngine implements Engine {

	String Name = " diesel engine";

	public String getEngineType() {
		return this.Name;
	}

}
