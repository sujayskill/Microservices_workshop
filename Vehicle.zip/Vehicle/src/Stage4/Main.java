package Stage4;

// human
public class Main {

	public static void main(String[] args) {

//		Dependency injection
		Vehicle v = new Vehicle(new DieselEngine());
		v.Start();
	
		
	}

}
