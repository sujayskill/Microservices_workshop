package Stage4;

public class Vehicle {

	Engine e;

	public Vehicle(Engine e) {
		this.e = e;

	}

	public void Start() {
		System.out.println("vehicle started"+e.getEngineType());
	}

}
