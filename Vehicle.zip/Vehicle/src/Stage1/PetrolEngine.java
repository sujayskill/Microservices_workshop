package Stage1;

public class PetrolEngine {

	String Name = " petrol engine";

	public String getEngineType() {
		return this.Name;
	}

}
