package Stage1;

public class Vehicle {

	PetrolEngine pe;

	public Vehicle() {
		this.pe = new PetrolEngine();

	}

	public void Start() {
		System.out.println(" vehicle started");
	}

}
