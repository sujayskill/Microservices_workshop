package Stage3;

public class Vehicle {

	Engine e;

	public Vehicle() {
		this.e = new DieselEngine();

	}

	public void Start() {
		System.out.println(" vehicle started"+e.getEngineType());
	}

}
