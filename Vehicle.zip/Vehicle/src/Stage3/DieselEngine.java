package Stage3;

public class DieselEngine implements Engine {

	String Name = " diesel engine";

	public String getEngineType() {
		return this.Name;
	}

}
