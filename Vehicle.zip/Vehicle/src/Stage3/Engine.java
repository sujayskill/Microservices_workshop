package Stage3;

public interface Engine {
	
	String getEngineType(); 

}
