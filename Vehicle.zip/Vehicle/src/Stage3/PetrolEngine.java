package Stage3;

public class PetrolEngine implements Engine {

	String Name = " petrol engine";

	public String getEngineType() {
		return this.Name;
	}

}
