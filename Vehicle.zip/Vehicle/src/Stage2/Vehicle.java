package Stage2;

public class Vehicle {

	DieselEngine pe;

	public Vehicle() {
		this.pe = new DieselEngine();

	}

	public void Start() {
		System.out.println(" vehicle started");
	}

}
