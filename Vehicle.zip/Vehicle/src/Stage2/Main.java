package Stage2;

// human
public class Main {

	public static void main(String[] args) {

		Vehicle v = new Vehicle();
		v.Start();
		
		
		
		
	}

}
