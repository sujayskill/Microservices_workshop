package Stage2;

public class DieselEngine {

	String Name = " diesel engine";

	public String getEngineType() {
		return this.Name;
	}

}
