package in.bank.accounts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import in.bank.accounts.config.AccountsConfigService;
import in.bank.accounts.model.Accounts;
import in.bank.accounts.model.ConfigProp;
import in.bank.accounts.model.Customers;
import in.bank.accounts.repository.AccountRepository;

@RestController
public class AccountsController {

	@Autowired
	private AccountRepository accountsRepository;

	@Autowired
	AccountsConfigService accountsConfig;

	@PostMapping("/accounts")
	public Accounts getAccountDetails(@RequestBody Customers customer) {
		Accounts accounts = accountsRepository.findByCustomerId(customer.getCustomerId());
		return accounts;
	}

	@GetMapping("/accounts/configProps")
	public String getPropertyDetails() throws JsonProcessingException {
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		ConfigProp properties = new ConfigProp(accountsConfig.getMsg(), accountsConfig.getBuildVersion(),
				accountsConfig.getMailDetails(), accountsConfig.getActiveBranches());
		String jsonStr = ow.writeValueAsString(properties);
		return jsonStr;

	}

}









































