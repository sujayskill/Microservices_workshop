package in.bank.cards.model;

//import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Customer {
	
	private int customerId;
	

}
